package poltek.informatika.retrofit;

import java.util.HashMap;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ServerApi {

    String BASE_URL = "http://192.168.43.90/server_api/";

    @Multipart
    @POST("api.php")
    Call<HashMap<String, String>> convertImage(@Part("foto\"; filename=\"myfile.png\" ") RequestBody file,
                                               @Part("text") RequestBody name);
}
